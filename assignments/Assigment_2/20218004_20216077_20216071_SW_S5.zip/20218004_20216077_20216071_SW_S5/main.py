import numpy as np
import random


def read_input(file):
    with open(file, 'r') as f:
        data = f.readlines()
        num_datasets = int(data[0])
        datasets = []
        idx = 1
        for _ in range(num_datasets):
            num_chemicals, total = map(float, data[idx].split())
            idx += 1
            bounds = [tuple(map(float, data[idx + i].split())) for i in range(int(num_chemicals))]
            idx += int(num_chemicals)
            costs = list(map(float, data[idx].split()))
            idx += 1
            datasets.append((int(num_chemicals), total, bounds, costs))
        return datasets


def initialize_population(size, num_chemicals, bounds, total):
    population = []
    for _ in range(size):
        solution = np.random.uniform(0, 1, num_chemicals)
        solution /= solution.sum()
        solution *= total
        solution = np.clip(solution, [b[0] for b in bounds], [b[1] for b in bounds])
        population.append(solution)
    return np.array(population)


def fitness_function(solution, costs):
    return np.dot(solution, costs)


def tournament_selection(pop, fits, k=3):
    selected = random.sample(range(len(pop)), k)
    best = min(selected, key=lambda x: fits[x])
    return pop[best]


def two_point_crossover(parent1, parent2):
    size = len(parent1)
    point1, point2 = sorted(random.sample(range(size), 2))
    child1 = np.concatenate([parent1[:point1], parent2[point1:point2], parent1[point2:]])
    child2 = np.concatenate([parent2[:point1], parent1[point1:point2], parent2[point2:]])
    return child1, child2


def non_uniform_mutation(solution, bounds, generation, max_gen, mutation_rate=0.1):
    for i in range(len(solution)):
        if random.random() < mutation_rate:
            delta = bounds[i][1] - bounds[i][0]
            factor = random.random() * (1 - (generation / max_gen))
            if random.random() < 0.5:
                solution[i] -= delta * factor
            else:
                solution[i] += delta * factor
            solution[i] = np.clip(solution[i], bounds[i][0], bounds[i][1])
    return solution


def genetic_algorithm(datasets, pop_size=50, generations=100, mutation_rate=0.1):
    results = []
    for dataset_idx, (num_chemicals, total, bounds, costs) in enumerate(datasets):
        pop = initialize_population(pop_size, num_chemicals, bounds, total)
        for gen in range(generations):
            fits = [fitness_function(ind, costs) for ind in pop]
            new_pop = []
            best_idx = np.argmin(fits)
            new_pop.append(pop[best_idx])  # Elitism
            while len(new_pop) < pop_size:
                parent1 = tournament_selection(pop, fits)
                parent2 = tournament_selection(pop, fits)
                child1, child2 = two_point_crossover(parent1, parent2)
                child1 = non_uniform_mutation(child1, bounds, gen, generations, mutation_rate)
                child2 = non_uniform_mutation(child2, bounds, gen, generations, mutation_rate)
                new_pop.extend([child1, child2])
            pop = np.array(new_pop[:pop_size])
        best_idx = np.argmin([fitness_function(ind, costs) for ind in pop])
        results.append((dataset_idx + 1, pop[best_idx], fitness_function(pop[best_idx], costs)))
    return results


def write_output(file, results):
    with open(file, 'w') as f:
        for idx, proportions, cost in results:
            f.write(f"Dataset {idx}\n")
            f.write(f"Chemical Proportions: {' '.join(f'{p:.2f}' for p in proportions)}\n")
            f.write(f"Total Cost: {cost:.2f}\n")


if __name__ == "__main__":
    input_file = "input.txt"
    output_file = "output.txt"
    datasets = read_input(input_file)
    results = genetic_algorithm(datasets)
    write_output(output_file, results)
